import type { ReactNode } from "react";
import Link from "next/link";

type Props = {
  children: ReactNode;
};

const navigation = [
  {
    href: "/super",
    label: "📊 Dashboard",
  },
  {
    href: "/super/restaurants",
    label: "🍽 Restaurantes",
  },
];

export default function SuperLayout({
  children,
}: Props) {
  return (
    <main className="min-h-screen bg-gray-100">
      <div className="flex min-h-screen">

        <aside className="w-72 border-r bg-white">
          <div className="border-b p-6">
            <h1 className="text-2xl font-bold">
              🌍 Digital Bar
            </h1>

            <p className="mt-1 text-sm text-gray-500">
              Plataforma
            </p>
          </div>

          <nav className="space-y-2 p-4">
            {navigation.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block rounded-xl px-4 py-3 transition hover:bg-amber-50 hover:text-amber-700"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </aside>

        <div className="flex flex-1 flex-col">

          <header className="border-b bg-white">
            <div className="flex items-center justify-between px-8 py-5">
              <div>
                <h2 className="text-2xl font-bold">
                  Super Administración
                </h2>

                <p className="text-sm text-gray-500">
                  Gestión de la plataforma
                </p>
              </div>
            </div>
          </header>

          <div className="flex-1 p-8">
            {children}
          </div>

        </div>
      </div>
    </main>
  );
}